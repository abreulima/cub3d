#include "cub3d.h"

void render_image(t_game game, t_comp_sprite s, )
{

}
